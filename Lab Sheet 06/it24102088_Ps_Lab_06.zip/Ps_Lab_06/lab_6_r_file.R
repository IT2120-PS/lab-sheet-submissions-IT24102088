setwd("C:\\Users\\supun\\OneDrive\\Desktop\\Ps_Lab_06\\")

#question 1
#part 1
#Binomial distribution
#random variable x has bionomial distribution with n=50 and p=0.85


#question 1
#part 2
pbinom(46, size=50, prob=0.85,lower.tail = FALSE)

#question 2
#part 1
#X = number of calls per hour
x<-12


#question 2
#part 2
#random variable x has distribution poisson 12

#question 1
#part 3
dpois(15, lambda=12)




