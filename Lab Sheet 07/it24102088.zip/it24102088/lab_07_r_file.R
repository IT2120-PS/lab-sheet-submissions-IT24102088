

setwd("C:\\Users\\supun\\OneDrive\\Desktop\\New folder (18)\\")

# Q1
# Probability that train arrives between 10 and 25 minutes
punif(25, min = 0, max = 40) - punif(10, min = 0, max = 40)


# Q2
# Probability that update takes at most 2 hours
pexp(2, rate = 1/3)


# Q3
# Probability that a person has IQ above 130
1 - pnorm(130, mean = 100, sd = 15)


# Q4: 
# IQ score at the 95th percentile
qnorm(0.95, mean = 100, sd = 15)

